# 📖 README – Installation Photomaton

## 1️⃣ Pré-requis matériel
- Raspberry Pi 4 (recommandé) avec Raspberry Pi OS Lite ou Desktop.  
- Écran tactile officiel 7" (HDMI/DSI).  
- Appareil photo reflex Canon compatible **gphoto2** (USB).  
- Imprimante **Canon Selphy CP1300** (Wi-Fi réseau ou Wi-Fi Direct).  
- (Optionnel) Anneau **NeoPixel WS2812** ou flash externe (piloté par GPIO).  

---

## 2️⃣ Pré-requis logiciel
Sur ton Raspberry :
```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y git unzip curl build-essential python3 python3-venv python3-pip gphoto2 cups
```

---

## 3️⃣ Récupération du projet
Si tu as l’archive `photomaton_full.zip` :
```bash
cd /home/pi
unzip photomaton_full.zip -d photomaton_full
```

Ou via GitHub (si version en ligne) :
```bash
git clone https://github.com/toncompte/photomaton.git photomaton_full
```

---

## 4️⃣ Installation automatique
Exécuter le script fourni :
```bash
chmod +x install_photomaton.sh
./install_photomaton.sh
```

Ce script :
- Installe **Node.js 18**, Python 3, gphoto2, CUPS.  
- Configure les backends **Node** et **Python**.  
- Compile le frontend React.  
- Installe le service **systemd** pour lancer le photomaton au démarrage.  

---

## 5️⃣ Impression – Canon Selphy CP1300
Deux modes sont disponibles :  

### Mode Réseau (recommandé)
```bash
cd photomaton_full/scripts
chmod +x install_cp1300.sh
./install_cp1300.sh <IP_de_la_CP1300>
```

### Mode Wi-Fi Direct
```bash
cd photomaton_full/scripts
chmod +x install_cp1300_direct.sh
./install_cp1300_direct.sh <SSID> <PASSWORD>
```

Vérification :
```bash
lpstat -p
```

---

## 6️⃣ Lancement manuel
### Backend Node
```bash
cd photomaton_full/node_backend
node server.js
```

### Backend Python
```bash
cd photomaton_full/python_backend
source venv/bin/activate
python server.py
```

### Frontend React
```bash
cd photomaton_full/frontend
npm run dev
```

---

## 7️⃣ Utilisation
- **UI tactile** : `http://localhost:3000`  
- **API backend** : `http://localhost:4002`  
- **Galerie** : `http://localhost:4002/`  
- **Diaporama** : `http://localhost:4002/slideshow`

---

## 8️⃣ Configuration
Tout est dans `photomaton_full/config.json` :  

- `eventTitle` → titre affiché  
- `eventLogo` → chemin vers logo transparent PNG  
- `photosPerSession` → nb de photos par session (par défaut 3)  
- `countdownSeconds` → délai compte à rebours  
- `flashMode` → `dslr` | `gpio` | `neopixel`  
- `printEnabled`, `printMode`, `printToPDF`, `printerName`  
- `themePreset` → `mariage` | `anniversaire` | `corporate` | `retro` | `custom`  

---

## 9️⃣ Désinstallation
```bash
chmod +x uninstall_photomaton.sh
./uninstall_photomaton.sh
```

---

## 🔟 Conseils
- Vérifie que `gphoto2 --auto-detect` détecte bien ton reflex Canon.  
- Vérifie que l’imprimante est ajoutée :  
  ```bash
  lpstat -p -d
  ```  
- Pour debug :  
  ```bash
  journalctl -u photomaton.service -f
  ```  
