#!/bin/bash
set -e
USER="denre"
INSTALL_DIR="/home/$USER/photomaton_simple"
NODE_VERSION="18"
PRINTER_NAME="Canon_SELPHY_CP1300"
echo "=== 🚀 Installation Photomaton simplifié ==="
sudo apt update && sudo apt upgrade -y
sudo apt install -y git curl wget unzip build-essential python3 python3-venv python3-pip cups libcups2-dev gphoto2 libgphoto2-dev libjpeg-dev libpng-dev
curl -fsSL https://deb.nodesource.com/setup_$NODE_VERSION.x | sudo -E bash -
sudo apt install -y nodejs
cd "$INSTALL_DIR/python_backend" && python3 -m venv venv && source venv/bin/activate && pip install --upgrade pip && pip install -r requirements.txt && deactivate
cd "$INSTALL_DIR/frontend" && npm install && npm run build
sudo usermod -a -G lpadmin $USER
sudo systemctl enable cups && sudo systemctl start cups
sudo cp "$INSTALL_DIR/scripts/photomaton-python.service" /etc/systemd/system/photomaton-python.service
sudo cp "$INSTALL_DIR/scripts/photomaton-frontend.service" /etc/systemd/system/photomaton-frontend.service
sudo systemctl daemon-reload
sudo systemctl enable photomaton-python.service
sudo systemctl enable photomaton-frontend.service
chmod -R 777 "$INSTALL_DIR"
echo "✅ Installation terminée."
echo "UI: http://localhost:3000"
