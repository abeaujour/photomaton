#!/bin/bash
set -e
sudo apt install -y chromium-browser unclutter xdotool
AUTOSTART_DIR="/home/denre/.config/lxsession/LXDE-pi"
AUTOSTART_FILE="$AUTOSTART_DIR/autostart"
mkdir -p "$AUTOSTART_DIR"
sed -i '/chromium-browser/d' "$AUTOSTART_FILE" 2>/dev/null || true
sed -i '/unclutter/d' "$AUTOSTART_FILE" 2>/dev/null || true
cat <<EOL >> "$AUTOSTART_FILE"
@unclutter -idle 0
@chromium-browser --noerrdialogs --disable-infobars --kiosk http://localhost:3000
EOL
