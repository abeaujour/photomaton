# 🚀 Installation Photomaton Simplifié

unzip photomaton_simple.zip -d ~/photomaton_simple
cd ~/photomaton_simple/scripts
bash install_photomaton_simple.sh

Accès:
- UI React: http://localhost:3000
