#!/bin/bash
set -e
AUTOSTART_DIR="/home/denre/.config/lxsession/LXDE-pi"
AUTOSTART_FILE="$AUTOSTART_DIR/autostart"
if [ -f "$AUTOSTART_FILE" ]; then
  sed -i '/chromium-browser/d' "$AUTOSTART_FILE"
  sed -i '/unclutter/d' "$AUTOSTART_FILE"
  echo "✅ Mode kiosque désactivé."
else
  echo "ℹ️ Aucun fichier autostart trouvé."
fi
