#!/bin/bash
set -e

echo "=== 🔄 Mise à jour Photomaton depuis GitHub ==="

INSTALL_DIR="/home/pi/photomaton_full"

# Aller dans le dossier
cd "$INSTALL_DIR"

# Vérifier si git est initialisé
if [ ! -d ".git" ]; then
  echo "❌ Erreur : pas de dépôt git trouvé dans $INSTALL_DIR"
  echo "➡️ Lance d'abord push_to_github.sh pour initialiser."
  exit 1
fi

echo "📥 Récupération des dernières modifications..."
git pull origin main

echo "📦 Mise à jour du backend Node"
cd "$INSTALL_DIR/node_backend"
npm install

echo "📦 Mise à jour du backend Python"
cd "$INSTALL_DIR/python_backend"
source venv/bin/activate
pip install -r requirements.txt
deactivate

echo "📦 Mise à jour du frontend React"
cd "$INSTALL_DIR/frontend"
npm install
npm run build

echo "🔁 Redémarrage du service photomaton"
sudo systemctl restart photomaton.service

echo "✅ Mise à jour terminée et service relancé !"
