# Installation rapide
1) Dézipper l'archive dans /home/denre/photomaton_full
2) Lancer : bash scripts/setup.sh (applique chmod 777 + enregistre services)
3) (Option) scripts/install_cp1300*.sh pour l'imprimante
4) (Option) scripts/enable_kiosk.sh pour le plein écran
Accès: UI http://localhost:3000 • Galerie http://localhost:4002/ • Slideshow http://localhost:4002/slideshow
