# 📸 Photomaton Simplifié

Version légère : Capture DSLR, assemblage planche 10x15, impression Canon Selphy CP1300 via WiFi.
