# 📸 Photomaton Événementiel

Un photomaton complet pour Raspberry Pi avec écran tactile 7", appareil photo reflex Canon et imprimante Canon Selphy CP1300.  
Conçu pour les mariages, anniversaires, événements d’entreprise et soirées festives.  

---

## ✨ Fonctionnalités principales

- 📷 **Capture DSLR** via `gphoto2` (Canon reflex en USB).  
- ⏱ **Compte à rebours personnalisable** avant chaque photo.  
- 🖼 **Assemblage automatique** en planche 10×15 cm (3 photos + logo).  
- 🏷 **Nommage structuré** des fichiers :  
  - `2025-09-26T21-32-15_Mariage_Alice_Bob_1.jpg`  
  - `2025-09-26T21-32-15_Mariage_Alice_Bob.jpg` (planche)  
  - `2025-09-26T21-32-15_Mariage_Alice_Bob.pdf` (planche PDF)  
- 🖨 **Impression directe** :  
  - Canon Selphy CP1300 (réseau ou Wi-Fi Direct).  
  - PDF généré automatiquement si option activée.  
- 💡 **Flash configurable** :  
  - Flash DSLR intégré.  
  - Flash LED via GPIO.  
  - Anneau **NeoPixel** avec animation (idle, countdown, flash).  
- 🌐 **Galerie web** intégrée :  
  - Accessible sur le même réseau Wi-Fi.  
  - Rafraîchissement automatique.  
  - Mode diaporama plein écran (projecteur).  
- 🎨 **Interface tactile (React)** :  
  - Boutons tactiles (démarrer, imprimer, télécharger, email).  
  - Thèmes prédéfinis (mariage, anniversaire, corporate, rétro, custom).  
  - Logo et titre modifiables via `config.json`.  
- ⚙️ **Configuration centralisée** dans `config.json`.  

---

## 📂 Arborescence du projet

```
photomaton/
│── backend/
│   ├── server.py            # API backend Python
│   ├── server.js            # API backend Node.js
│   ├── dslr_capture.py      # gestion DSLR
│   ├── assemble.py          # création planches 10x15
│   ├── printer.py           # impression
│   ├── led_control.py       # gestion LED / NeoPixel
│   └── utils.py
│
│── frontend/                # UI React tactile
│   ├── src/
│   │   ├── App.jsx          # interface principale
│   │   ├── Countdown.jsx    # compte à rebours
│   │   ├── Gallery.jsx      # galerie web
│   │   └── Carousel.jsx     # diaporama
│
│── assets/                  # logo, polices, images
│── scripts/                 # installation imprimante, service systemd
│── docs/
│   ├── INSTALL.md           # guide d'installation
│   └── README.md            # documentation
└── config.json              # configuration principale
```

---

## 🚀 Installation rapide

```bash
chmod +x install_photomaton.sh
./install_photomaton.sh
```

Détails dans [INSTALL.md](./INSTALL.md).

---

## 🎛 Configuration (`config.json`)

- `eventTitle` : titre affiché.  
- `eventLogo` : chemin vers logo transparent PNG.  
- `photosPerSession` : nombre de photos par session.  
- `countdownSeconds` : délai compte à rebours.  
- `flashMode` : `dslr` | `gpio` | `neopixel`.  
- `printEnabled`, `printMode`, `printToPDF`, `printerName`.  
- `themePreset` : `mariage` | `anniversaire` | `corporate` | `retro` | `custom`.  

---

## 🖥 Utilisation

- **UI tactile** : `http://localhost:3000`  
- **API backend** : `http://localhost:4002`  
- **Galerie** : `http://localhost:4002/`  
- **Diaporama** : `http://localhost:4002/slideshow`  

---

## 🛠 Dépannage

- Vérifier la détection du reflex :  
  ```bash
  gphoto2 --auto-detect
  ```
- Vérifier l’imprimante :  
  ```bash
  lpstat -p -d
  ```
- Logs du service :  
  ```bash
  journalctl -u photomaton.service -f
  ```

---

## 📜 Licence

Projet libre pour usage personnel et événementiel.  
N’hésitez pas à adapter, améliorer et contribuer.  
