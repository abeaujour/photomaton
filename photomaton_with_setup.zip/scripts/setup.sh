#!/bin/bash
set -e

USER="denre"
INSTALL_DIR="/home/$USER/photomaton_full"

echo "=== 🚀 Setup Photomaton (user: $USER) ==="

# Vérifier installation
if [ ! -d "$INSTALL_DIR" ]; then
  echo "❌ Le dossier $INSTALL_DIR n'existe pas. Dézippe d'abord photomaton_super_denre_final.zip"
  exit 1
fi

cd "$INSTALL_DIR"

# Donner accès complet (⚠️ attention sécurité)
echo "=== 🔑 Permissions 777 sur tout le projet ==="
chmod -R 777 "$INSTALL_DIR"

# Dépendances système minimales
echo "=== 📦 Installation dépendances système ==="
sudo apt update
sudo apt install -y cups git curl wget unzip build-essential

# Installation des services systemd
echo "=== ⚙️ Installation des services systemd ==="
sudo cp "$INSTALL_DIR/scripts/photomaton.service" /etc/systemd/system/photomaton.service
sudo cp "$INSTALL_DIR/scripts/photomaton-node.service" /etc/systemd/system/photomaton-node.service
sudo cp "$INSTALL_DIR/scripts/photomaton-python.service" /etc/systemd/system/photomaton-python.service

sudo systemctl daemon-reload

# Demander mode
echo ""
echo "Choisis ton mode de démarrage automatique :"
echo "1) Service global unique (photomaton.service)"
echo "2) Services séparés (photomaton-node.service + photomaton-python.service)"
read -p "Ton choix (1/2) : " choice

if [ "$choice" = "1" ]; then
  sudo systemctl enable photomaton.service
  echo "✅ Mode global activé (photomaton.service)"
elif [ "$choice" = "2" ]; then
  sudo systemctl enable photomaton-node.service
  sudo systemctl enable photomaton-python.service
  echo "✅ Mode séparé activé (node + python)"
else
  echo "ℹ️ Aucun service activé automatiquement. Tu pourras le faire manuellement."
fi

echo ""
echo "➡️ Tu peux démarrer les services avec :"
echo "   sudo systemctl start photomaton.service"
echo "   ou"
echo "   bash scripts/start_all.sh"
echo ""
echo "🎉 Setup terminé."
