#!/bin/bash
PRINTER_NAME="Canon_SELPHY_CP1300"
PRINTER_IP="$1"
if [ -z "$PRINTER_IP" ]; then echo "Usage: $0 <IP_CP1300>"; exit 1; fi
sudo apt update; sudo apt -y install cups
sudo usermod -a -G lpadmin denre
sudo systemctl enable cups; sudo systemctl start cups
sudo lpadmin -p $PRINTER_NAME -E -v ipp://$PRINTER_IP:631/ipp/print -m everywhere
echo "Test: lp -d $PRINTER_NAME /usr/share/cups/data/testprint"
