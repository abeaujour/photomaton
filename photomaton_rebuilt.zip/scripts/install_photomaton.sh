#!/bin/bash
set -e
USER="denre"
INSTALL_DIR="/home/$USER/photomaton_full"
NODE_VERSION="18"
echo "=== 🚀 Installation Photomaton ==="
sudo apt update && sudo apt upgrade -y
sudo apt install -y git curl wget unzip build-essential python3 python3-venv python3-pip cups libcups2-dev gphoto2 libgphoto2-dev libudev-dev libjpeg-dev libpng-dev
curl -fsSL https://deb.nodesource.com/setup_$NODE_VERSION.x | sudo -E bash -
sudo apt install -y nodejs
mkdir -p "$INSTALL_DIR"
cd "$INSTALL_DIR"
cd "$INSTALL_DIR/node_backend" && npm install || true
cd "$INSTALL_DIR/python_backend" && python3 -m venv venv && source venv/bin/activate && pip install --upgrade pip && pip install -r requirements.txt && deactivate || true
cd "$INSTALL_DIR/frontend" && npm install && npm run build || true
sudo usermod -a -G lpadmin $USER
sudo systemctl enable cups && sudo systemctl start cups
sudo cp "$INSTALL_DIR/scripts/photomaton.service" /etc/systemd/system/photomaton.service
sudo cp "$INSTALL_DIR/scripts/photomaton-node.service" /etc/systemd/system/photomaton-node.service
sudo cp "$INSTALL_DIR/scripts/photomaton-python.service" /etc/systemd/system/photomaton-python.service
sudo systemctl daemon-reload
echo "✅ Installation terminée."
