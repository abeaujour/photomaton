# 📸 Photomaton Événementiel (user: denre)

- DSLR (gphoto2) • Assemblage 10x15 • Impression Selphy/PDF • Galerie & Slideshow • UI React
- Config via `config.json`. Services systemd: global ou séparé (Node+Frontend / Python). Helpers inclus.
