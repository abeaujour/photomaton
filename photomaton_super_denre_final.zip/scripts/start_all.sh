#!/bin/bash
set -e
sudo systemctl start photomaton-node.service
sudo systemctl start photomaton-python.service
echo "✅ Tous les services Photomaton démarrés."
