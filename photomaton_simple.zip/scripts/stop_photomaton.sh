#!/bin/bash
set -e
USER="denre"
INSTALL_DIR="/home/$USER/photomaton_simple"
echo "=== 🛑 Arrêt Photomaton simplifié ==="
if [ -f "$INSTALL_DIR/backend.pid" ]; then kill $(cat "$INSTALL_DIR/backend.pid") 2>/dev/null || true; rm "$INSTALL_DIR/backend.pid"; echo "➡️ Backend arrêté"; fi
if [ -f "$INSTALL_DIR/frontend.pid" ]; then kill $(cat "$INSTALL_DIR/frontend.pid") 2>/dev/null || true; rm "$INSTALL_DIR/frontend.pid"; echo "➡️ Frontend arrêté"; fi
echo "✅ Photomaton stoppé"
