#!/bin/bash
set -e

echo "=== 🚀 Envoi du projet Photomaton vers GitHub ==="

USER_GITHUB="abeaujour"
REPO="photomaton"
GIT_URL="https://github.com/$USER_GITHUB/$REPO.git"

# Aller dans le projet
cd ~/photomaton_full

# Initialiser le dépôt si pas déjà fait
if [ ! -d ".git" ]; then
  git init
  git branch -M main
fi

# Ajouter les fichiers
git add .

# Commit avec message par défaut si aucun en cours
if ! git diff --cached --quiet; then
  git commit -m "✨ Initial commit : Photomaton complet"
fi

# Ajouter remote si pas encore présent
if ! git remote | grep origin > /dev/null; then
  git remote add origin $GIT_URL
fi

# Pousser vers GitHub
echo "📤 Push vers $GIT_URL"
git push -u origin main

echo "✅ Projet envoyé sur GitHub: $GIT_URL"
