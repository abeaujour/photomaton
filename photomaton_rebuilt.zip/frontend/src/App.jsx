import React, { useEffect, useState } from 'react'

export default function App() {
  const [settings, setSettings] = useState(null);
  const [started, setStarted] = useState(false);
  const [shooting, setShooting] = useState(false);
  const [countdown, setCountdown] = useState(null);
  const [shots, setShots] = useState([]);
  const [plancheUrl, setPlancheUrl] = useState(null);

  useEffect(() => { fetch('http://localhost:4002/config').then(r=>r.json()).then(setSettings); }, []);

  function theme() { if(!settings) return {gradientColors:['#000','#333'], titleColor:'#fff', buttonStyle:'rounded', fontFamily:'sans-serif'}; const t=settings.themes[settings.themePreset]||settings.themes.custom; return t; }
  function bgStyle(){ const t=theme(); return { background:`linear-gradient(135deg, ${t.gradientColors.join(',')})`, fontFamily:t.fontFamily, color:t.titleColor, minHeight:'100vh' }; }
  async function wait(ms){ return new Promise(r=>setTimeout(r,ms)); }
  async function countdownFrom(n){ for(let i=n;i>0;i--){ setCountdown(i); await wait(1000);} setCountdown(null); }
  async function takeBurst(){
    if(!settings) return;
    setShooting(true); const list=[];
    for(let i=0;i<settings.photosPerSession;i++){
      await countdownFrom(settings.countdownSeconds||3);
      const r = await fetch('http://localhost:4002/dslr/capture',{method:'POST'});
      if(r.ok){ const d=await r.json(); list.push(`http://localhost:4002${d.url}`); }
    }
    setShots(list); setShooting(false);
  }
  async function assemble(){
    const r = await fetch('http://localhost:4002/assemble', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ photos: shots.map(u=>u.replace("http://localhost:4002","")) }) });
    if(r.ok){ const d=await r.json(); setPlancheUrl(`http://localhost:4002${d.url}`); }
  }
  async function printPlanche(){
    if(!plancheUrl || !settings) return;
    const localPath = plancheUrl.replace('http://localhost:4002','');
    const parts = localPath.split('/'); const day=parts[2]; const filename=parts.pop();
    const abs = `${settings.baseDir}/${day}/${filename}`;
    await fetch('http://localhost:4002/print',{method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ file: abs })});
  }

  if(!settings){ return <div style={{padding:20}}>Chargement…</div>; }
  const t = theme();

  return (
    <div style={bgStyle()}>
      {!started ? (
        <div style={{display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',height:'100vh',gap:12}}>
          <img src={'/logo/logo.png'} onError={()=>{}} alt="" style={{height:80}}/>
          <h1 style={{color:t.titleColor}}>{settings.eventTitle}</h1>
          <button onClick={()=>setStarted(true)} style={{padding:'14px 22px', borderRadius: t.buttonStyle==='rounded'?'999px':'6px', background:'#fff', color:'#111', fontWeight:700}}>🚀 Démarrer</button>
        </div>
      ) : (
        <div style={{maxWidth:1000, margin:'0 auto', padding:16}}>
          <h2 style={{color:'#fff'}}>Photomaton</h2>
          <div style={{position:'relative', background:'rgba(0,0,0,0.3)', borderRadius:16, padding:20, minHeight:300}}>
            {countdown && <div style={{position:'absolute', inset:0, display:'flex',alignItems:'center',justifyContent:'center', fontSize:96, color:t.countdownColor, fontWeight:800}}>{countdown}</div>}
            {!countdown && <div style={{color:'#eee'}}>Prêt à capturer…</div>}
          </div>
          <div style={{display:'flex', gap:8, marginTop:12, flexWrap:'wrap'}}>
            <button disabled={shooting} onClick={takeBurst} style={{padding:'10px 18px', borderRadius:12, fontWeight:700}}>📸 Prendre {settings.photosPerSession} photos</button>
            <button disabled={shots.length<settings.photosPerSession} onClick={assemble} style={{padding:'10px 18px', borderRadius:12, fontWeight:700}}>🧩 Assembler 10×15</button>
            {(settings.printEnabled && (settings.printMode==='manual' || settings.printMode==='both')) && (
              <button onClick={printPlanche} style={{padding:'10px 18px', borderRadius:12, fontWeight:700}}>🖨️ Imprimer</button>
            )}
            <a href="http://localhost:4002/" target="_blank" style={{padding:'10px 18px', borderRadius:12, fontWeight:700, background:'#fff', color:'#111', textDecoration:'none'}}>🖼️ Galerie</a>
          </div>
          {shots.length>0 && (
            <div style={{display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:8, marginTop:12}}>
              {shots.map((s,i)=>(<img key={i} src={s} style={{width:'100%', borderRadius:12}}/>))}
            </div>
          )}
          {plancheUrl && (
            <div style={{marginTop:12}}>
              <h3 style={{color:'#fff'}}>Planche assemblée</h3>
              <img src={plancheUrl} style={{maxWidth:'100%', borderRadius:12}}/>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
