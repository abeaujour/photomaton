#!/bin/bash
PRINTER_NAME="Canon_SELPHY_CP1300_DIRECT"
PRINTER_IP="192.168.4.1"
SSID="$1"; PSK="$2"
if [ -z "$SSID" ] || [ -z "$PSK" ]; then echo "Usage: $0 <SSID_CP1300> <PASSWORD>"; exit 1; fi
cat <<EOF | sudo tee -a /etc/wpa_supplicant/wpa_supplicant.conf > /dev/null
network={
  ssid="$SSID"
  psk="$PSK"
}
EOF
sudo wpa_cli -i wlan0 reconfigure
sleep 10
sudo apt update; sudo apt -y install cups
sudo usermod -a -G lpadmin denre
sudo systemctl enable cups; sudo systemctl start cups
sudo lpadmin -p $PRINTER_NAME -E -v ipp://$PRINTER_IP:631/ipp/print -m everywhere
echo "Test: lp -d $PRINTER_NAME /usr/share/cups/data/testprint"
