#!/bin/bash
set -e
sudo systemctl stop photomaton-node.service
sudo systemctl stop photomaton-python.service
echo "🛑 Tous les services Photomaton arrêtés."
