#!/bin/bash
set -e
USER="denre"
INSTALL_DIR="/home/$USER/photomaton_simple"
echo "=== 🚀 Lancement Photomaton simplifié ==="
cd "$INSTALL_DIR/python_backend"
source venv/bin/activate
nohup python server.py > backend.log 2>&1 &
BACK_PID=$!
deactivate
cd "$INSTALL_DIR/frontend"
nohup npm run preview -- --port 3000 > frontend.log 2>&1 &
FRONT_PID=$!
echo $BACK_PID > "$INSTALL_DIR/backend.pid"
echo $FRONT_PID > "$INSTALL_DIR/frontend.pid"
echo "✅ Photomaton lancé ! UI: http://localhost:3000"
