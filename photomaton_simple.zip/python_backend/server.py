from fastapi import FastAPI, Body
from fastapi.responses import JSONResponse
import uvicorn, subprocess, os, json, time
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
CONFIG = json.load(open(ROOT / "config.json", "r"))
BASE_DIR = ROOT / "photos"

app = FastAPI()

def ensure_day_folder():
    now = time.strftime("%Y-%m-%d")
    folder = BASE_DIR / now
    folder.mkdir(parents=True, exist_ok=True)
    return now, folder

def safe_title():
    title = CONFIG.get("eventTitle", "Photomaton")
    out = "".join([c if c.isalnum() else "_" for c in title]).strip("_")
    return out[:30] or "Photomaton"

def timestamp_name(ext="jpg", suffix=None):
    ts = time.strftime("%Y-%m-%dT%H-%M-%S")
    t = safe_title()
    return f"{ts}_{t}_{suffix}.{ext}" if suffix else f"{ts}_{t}.{ext}"

@app.post("/dslr/capture")
def dslr_capture():
    now_day, folder = ensure_day_folder()
    name = timestamp_name("jpg")
    filepath = folder / name
    cmd = ["gphoto2", "--capture-image-and-download", f"--filename={filepath}"]
    try:
        subprocess.check_call(cmd)
    except subprocess.CalledProcessError as e:
        return JSONResponse({"error": "capture failed", "detail": str(e)}, status_code=500)
    return {"path": str(filepath), "url": f"/photos/{now_day}/{name}"}

@app.post("/assemble")
def assemble(data=Body(...)):
    photos = data.get("photos", [])
    if len(photos) < CONFIG.get("photosPerSession", 3):
        return JSONResponse({"error": "not enough photos"}, status_code=400)

    dpi = CONFIG.get("dpi", 300)
    w = round((10/2.54)*dpi); h = round((15/2.54)*dpi)
    cellW = w//2; cellH = h//2

    now_day, folder = ensure_day_folder()
    planche_name = timestamp_name("jpg")
    planche_path = folder / planche_name

    canvas = Image.new("RGB", (w, h), "white")

    for i in range(3):
        p = photos[i]
        img = Image.open(p).convert("RGB")
        img = img.resize((cellW, cellH), Image.LANCZOS)
        x = (i % 2) * cellW
        y = (i // 2) * cellH
        canvas.paste(img, (x, y))

    logo_path = ROOT / "assets" / os.path.basename(CONFIG.get("eventLogo","logo.png"))
    if logo_path.exists():
        logo = Image.open(logo_path).convert("RGBA").resize((cellW, cellH), Image.LANCZOS)
        canvas.paste(logo, (cellW, cellH), logo)

    canvas.save(planche_path, "JPEG", quality=95)

    if CONFIG.get("printEnabled", False) and CONFIG.get("printMode") in ("auto", "both"):
        copies = str(CONFIG.get("printCopies", 1))
        printer = CONFIG.get("printerName", "Canon_SELPHY_CP1300")
        try:
            subprocess.check_call(["lp", "-d", printer, "-n", copies, str(planche_path)])
        except Exception as e:
            print("print failed:", e)

    return {"planchePath": str(planche_path), "url": str(planche_path)}

@app.post("/print")
def print_file(data=Body(...)):
    file = data.get("file")
    if not CONFIG.get("printEnabled", False):
        return JSONResponse({"error": "printing disabled"}, status_code=403)
    copies = str(CONFIG.get("printCopies", 1))
    printer = CONFIG.get("printerName", "Canon_SELPHY_CP1300")
    try:
        subprocess.check_call(["lp", "-d", printer, "-n", copies, file])
    except Exception as e:
        return JSONResponse({"error": "print failed", "detail": str(e)}, status_code=500)
    return {"status": "ok"}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=4002)
