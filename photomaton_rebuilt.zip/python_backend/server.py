from fastapi import FastAPI, Body
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
import uvicorn, subprocess, os, json, time
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
CONFIG = json.load(open(ROOT / "config.json", "r"))
BASE_DIR = Path(CONFIG["baseDir"])

app = FastAPI()
app.mount("/photos", StaticFiles(directory=str(BASE_DIR), html=False), name="photos")
app.mount("/assets", StaticFiles(directory=str(ROOT / "assets")), name="assets")

def ensure_day_folder():
    now = time.strftime("%Y-%m-%d")
    folder = BASE_DIR / now
    folder.mkdir(parents=True, exist_ok=True)
    return now, folder

def safe_title():
    title = CONFIG.get("eventTitle", "Photomaton")
    out = "".join([c if c.isalnum() else "_" for c in title]).strip("_")
    return out[:30] or "Photomaton"

def timestamp_name(ext="jpg", suffix=None):
    ts = time.strftime("%Y-%m-%dT%H-%M-%S")
    t = safe_title()
    return f"{ts}_{t}_{suffix}.{ext}" if suffix else f"{ts}_{t}.{ext}"

@app.get("/config")
def get_config():
    return CONFIG

@app.post("/dslr/capture")
def dslr_capture():
    now_day, folder = ensure_day_folder()
    name = timestamp_name("jpg")
    filepath = folder / name
    cmd = ["gphoto2", "--capture-image-and-download", f"--filename={filepath}"]
    try:
        subprocess.check_call(cmd)
    except subprocess.CalledProcessError as e:
        return JSONResponse({"error": "capture failed", "detail": str(e)}, status_code=500)
    return {"path": str(filepath), "url": f"/photos/{now_day}/{name}"}

@app.post("/assemble")
def assemble(data=Body(...)):
    photos = data.get("photos", [])
    if len(photos) < CONFIG.get("photosPerSession", 3):
        return JSONResponse({"error": "not enough photos"}, status_code=400)

    dpi = CONFIG.get("dpi", 300)
    w = round((10/2.54)*dpi); h = round((15/2.54)*dpi)
    cellW = w//2; cellH = h//2

    now_day, folder = ensure_day_folder()
    planche_name = timestamp_name("jpg")
    planche_path = folder / planche_name

    canvas = Image.new("RGB", (w, h), "white")

    for i in range(3):
        p = photos[i]
        if p.startswith("/photos/"):
            rel = p.replace("/photos/", "")
            img = Image.open(BASE_DIR / rel).convert("RGB")
        else:
            img = Image.open(p).convert("RGB")
        img = img.resize((cellW, cellH), Image.LANCZOS)
        x = (i % 2) * cellW
        y = (i // 2) * cellH
        canvas.paste(img, (x, y))

    logo_path = ROOT / "assets" / os.path.basename(CONFIG.get("eventLogo","logo.png"))
    if logo_path.exists():
        logo = Image.open(logo_path).convert("RGBA").resize((cellW, cellH), Image.LANCZOS)
        canvas.paste(logo, (cellW, cellH), logo)

    canvas.save(planche_path, "JPEG", quality=95)

    if CONFIG.get("printToPDF", True):
        pdf_dir = Path(CONFIG.get("pdfOutputDir", "/home/denre/photomaton-pdf"))
        pdf_dir.mkdir(parents=True, exist_ok=True)
        pdf_name = planche_name.replace(".jpg", ".pdf")
        pdf_path = pdf_dir / pdf_name
        try:
            with open(pdf_path, "wb") as f:
                subprocess.check_call(["cupsfilter", str(planche_path)], stdout=f)
        except Exception:
            canvas_rgb = canvas.convert("RGB")
            canvas_rgb.save(pdf_path, "PDF", resolution=300, save_all=False)

    if CONFIG.get("printEnabled", False) and CONFIG.get("printMode") in ("auto", "both"):
        copies = str(CONFIG.get("printCopies", 1))
        printer = CONFIG.get("printerName", "Canon_SELPHY_CP1300")
        try:
            subprocess.check_call(["lp", "-d", printer, "-n", copies, str(planche_path)])
        except Exception as e:
            print("print failed:", e)

    return {"planchePath": str(planche_path), "url": f"/photos/{now_day}/{planche_name}"}

@app.get("/photos-list")
def photos_list():
    BASE_DIR.mkdir(parents=True, exist_ok=True)
    days = sorted([d for d in BASE_DIR.iterdir() if d.is_dir()], reverse=True)
    imgs = []
    for day in days:
        files = sorted([f for f in day.iterdir() if f.suffix.lower()=='.jpg'])
        for f in files:
            imgs.append(f"/photos/{day.name}/{f.name}")
    return imgs

@app.get("/slideshow", response_class=HTMLResponse)
def slideshow():
    interval = CONFIG.get("slideshowInterval", 5000)
    refresh = CONFIG.get("galleryRefreshMs", 30000)
    html = []
    html.append("<html><head><meta charset='utf-8'><title>Slideshow</title>")
    html.append("<style>body{margin:0;background:#000;display:flex;align-items:center;justify-content:center;height:100vh}")
    html.append("img{max-width:100%;max-height:100%;border-radius:8px}</style></head>")
    html.append("<body><img id='slide'/><script>")
    html.append(f"const interval={interval}; const refresh={refresh}; let imgs=[], idx=0;")
    html.append("function tick(){ if(imgs.length){ document.getElementById('slide').src = imgs[idx]; idx=(idx+1)%imgs.length; } }")
    html.append("async function refreshList(){ try{ const r=await fetch('/photos-list'); imgs=await r.json(); idx=0; }catch(e){} }")
    html.append("setInterval(tick, interval); setInterval(refreshList, refresh); refreshList(); tick();")
    html.append("</script></body></html>")
    return HTMLResponse("".join(html))

@app.get("/", response_class=HTMLResponse)
def gallery():
    BASE_DIR.mkdir(parents=True, exist_ok=True)
    days = sorted([d for d in BASE_DIR.iterdir() if d.is_dir()], reverse=True)
    theme = CONFIG["themes"][CONFIG["themePreset"]]
    grad = ",".join(theme["gradientColors"])
    html = []
    html.append("<html><head><meta charset='utf-8'><title>"+CONFIG['eventTitle']+"</title>")
    html.append("<style>")
    html.append("body{margin:0;padding:1em;background:linear-gradient(45deg,"+grad+");color:#fff;font-family:sans-serif}")
    html.append("h1{ text-align:center; margin:0 0 10px 0 }")
    html.append("h2{ margin-top:1em; border-bottom:1px solid rgba(255,255,255,0.4) }")
    html.append(".grid{ display:flex; flex-wrap:wrap; gap:12px }")
    html.append("img{ height:160px; border-radius:12px; box-shadow:0 4px 12px rgba(0,0,0,0.3) }")
    html.append(".toolbar{ text-align:center; margin:12px 0 }")
    html.append(".btn{ padding:8px 14px; border-radius:10px; background:#ffffff; color:#111; font-weight:bold }")
    html.append("</style></head><body>")
    html.append("<h1>"+CONFIG['eventTitle']+"</h1>")
    html.append("<div class='toolbar'><a class='btn' href='/slideshow' target='_blank'>Ouvrir le diaporama</a></div>")
    for day in days:
        html.append("<h2>"+day.name+"</h2><div class='grid'>")
        files = sorted([f for f in day.iterdir() if f.suffix.lower()=='.jpg'])
        for f in files:
            rel = f"{day.name}/{f.name}"
            html.append(f"<a href='/photos/{rel}' target='_blank'><img src='/photos/{rel}'/></a>")
        html.append("</div>")
    html.append(f"<script>setInterval(()=>location.reload(), {CONFIG.get('galleryRefreshMs',30000)});</script>")
    html.append("</body></html>")
    return HTMLResponse("".join(html))

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=CONFIG.get("backendPort", 4002))
