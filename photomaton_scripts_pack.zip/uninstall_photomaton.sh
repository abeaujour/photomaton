#!/bin/bash
set -e

echo "=== 🗑️ Désinstallation Photomaton ==="

USER="pi"
INSTALL_DIR="/home/$USER/photomaton_full"

echo "🛑 Arrêt et suppression du service systemd"
sudo systemctl stop photomaton.service || true
sudo systemctl disable photomaton.service || true
sudo rm -f /etc/systemd/system/photomaton.service
sudo systemctl daemon-reload

echo "🗑️ Suppression du dossier d'installation $INSTALL_DIR"
rm -rf "$INSTALL_DIR"

echo "🗑️ Suppression des paquets Node, Python venv, dépendances locales laissées par Photomaton"
# Attention : ne pas supprimer globalement Node ou Python car ils peuvent être utilisés par d'autres projets
# On ne fait que nettoyer le venv local et node_modules

echo "✅ Désinstallation terminée."
