#!/bin/bash
set -e
USER="denre"
INSTALL_DIR="/home/$USER/photomaton_full"
for s in photomaton.service photomaton-node.service photomaton-python.service; do
  sudo systemctl stop $s || true
  sudo systemctl disable $s || true
  sudo rm -f /etc/systemd/system/$s
done
sudo systemctl daemon-reload
rm -rf "$INSTALL_DIR"
echo "✅ Désinstallation terminée."
