#!/bin/bash
set -e

echo "=== ♻️ Redémarrage rapide du Photomaton ==="

sudo systemctl restart photomaton.service

echo "✅ Service photomaton redémarré avec succès !"
echo "➡️ Vérifie sur http://localhost:4002 ou ton IP Raspberry"
