import React, { useState } from 'react'

export default function App() {
  const [started, setStarted] = useState(false);
  const [countdown, setCountdown] = useState(null);
  const [shots, setShots] = useState([]);
  const [planche, setPlanche] = useState(null);
  const [printing, setPrinting] = useState(false);

  async function wait(ms){ return new Promise(r=>setTimeout(r,ms)); }
  async function captureBurst(){
    setShots([]); setPlanche(null);
    let tmp=[];
    for(let i=0;i<3;i++){
      for(let s=3;s>0;s--){ setCountdown(s); await wait(1000); }
      setCountdown(null);
      const r = await fetch('http://localhost:4002/dslr/capture',{method:'POST'});
      if(r.ok){ const d=await r.json(); tmp.push(d.path); }
    }
    setShots(tmp);
  }
  async function assemble(){
    const r = await fetch('http://localhost:4002/assemble',{method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ photos: shots })});
    if(r.ok){ const d=await r.json(); setPlanche(d.planchePath); }
  }
  async function printPlanche(){
    if(!planche) return;
    setPrinting(true);
    await fetch('http://localhost:4002/print',{method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ file: planche })});
    setPrinting(false);
  }

  if(!started){
    return <div style={{display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',height:'100vh',background:'linear-gradient(135deg,#f58529,#dd2a7b,#8134af,#515bd4)',color:'#fff'}}>
      <img src="/logo.png" alt="logo" style={{height:80}}/>
      <h1>Photomaton</h1>
      <button onClick={()=>setStarted(true)} style={{padding:'20px 40px',borderRadius:30,fontSize:22,fontWeight:700}}>📸 Démarrer</button>
    </div>
  }

  return <div style={{padding:20,background:'#000',minHeight:'100vh',color:'#fff'}}>
    {countdown && <div style={{fontSize:120,textAlign:'center'}}>{countdown}</div>}
    {!countdown && shots.length<3 && <div style={{textAlign:'center'}}><button onClick={captureBurst} style={{padding:'14px 24px',borderRadius:20,fontSize:20}}>📸 Prendre 3 photos</button></div>}
    {shots.length===3 && !planche && <div style={{textAlign:'center'}}><button onClick={assemble} style={{padding:'14px 24px',borderRadius:20,fontSize:20}}>🧩 Assembler</button></div>}
    {planche && <div style={{textAlign:'center'}}>
      <h2>Planche assemblée</h2>
      <img src={planche} style={{maxWidth:'100%'}}/>
      <div><button onClick={printPlanche} disabled={printing} style={{marginTop:12,padding:'14px 24px',borderRadius:20,fontSize:20}}>🖨️ {printing?'Impression...':'Imprimer'}</button></div>
    </div>}
  </div>
}
