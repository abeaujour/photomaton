# 📸 Photomaton Événementiel

Photomaton complet pour Raspberry Pi avec écran tactile 7".  
Fonctionnalités principales :
- Capture DSLR (Canon via gphoto2)
- Assemblage automatique en planche 10x15 (3 photos + logo)
- Impression Canon Selphy CP1300 (ou PDF)
- Galerie web + diaporama auto-refresh
- Interface tactile React
- Contrôle LEDs / flash via GPIO ou NeoPixel Ring
- Configuration simple via `config.json`

## 🚀 Services systemd

Trois choix sont possibles :

### 1. Service global unique
```bash
sudo systemctl enable photomaton.service
sudo systemctl start photomaton.service
```
➡️ Lance **Node backend + Frontend** ensemble.

### 2. Services séparés
```bash
sudo systemctl enable photomaton-node.service
sudo systemctl enable photomaton-python.service
sudo systemctl start photomaton-node.service
sudo systemctl start photomaton-python.service
```
➡️ Lance **Node backend + frontend** et **Python backend** séparément (plus robuste).

### 3. Helpers
Utiliser les scripts :
```bash
bash scripts/start_all.sh   # démarre node + python
bash scripts/stop_all.sh    # arrête node + python
```

## 📂 Dossiers
- `node_backend/` → serveur Node (API + galerie + slideshow)
- `python_backend/` → serveur Python (FastAPI, capture DSLR, assemblage, impression)
- `frontend/` → interface React tactile
- `assets/` → logos et thèmes graphiques
- `scripts/` → installation, services systemd, helpers
- `docs/` → documentation

## 🔧 Installation rapide
```bash
cd ~/photomaton_full
bash scripts/install_photomaton.sh
```

Puis configure l’imprimante si besoin (`install_cp1300.sh`).

Accès web :
- UI React : http://localhost:3000  
- Galerie : http://localhost:4002/  
- Diaporama : http://localhost:4002/slideshow  
