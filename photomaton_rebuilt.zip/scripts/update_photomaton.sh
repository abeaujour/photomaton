#!/bin/bash
set -e
INSTALL_DIR="/home/denre/photomaton_full"
cd "$INSTALL_DIR" || { echo "❌ Projet introuvable"; exit 1; }
git pull origin main || true
cd "$INSTALL_DIR/node_backend" && npm install || true
cd "$INSTALL_DIR/python_backend" && source venv/bin/activate && pip install -r requirements.txt && deactivate || true
cd "$INSTALL_DIR/frontend" && npm install && npm run build || true
sudo systemctl restart photomaton-node.service || true
sudo systemctl restart photomaton-python.service || true
echo "✅ Mise à jour terminée."
