#!/bin/bash
set -e

echo "=== 🚀 Installation Photomaton ==="

# --- Variables ---
USER="pi"
INSTALL_DIR="/home/$USER/photomaton_full"
NODE_VERSION="18"

echo "📦 Mise à jour du système"
sudo apt update && sudo apt upgrade -y

echo "📦 Installation des dépendances système"
sudo apt install -y   git curl wget unzip build-essential python3 python3-venv python3-pip   cups libcups2-dev gphoto2 libgphoto2-dev libudev-dev   libjpeg-dev libpng-dev

# --- Node.js ---
echo "📦 Installation de Node.js v$NODE_VERSION"
curl -fsSL https://deb.nodesource.com/setup_$NODE_VERSION.x | sudo -E bash -
sudo apt install -y nodejs

# --- Vérification Node/NPM ---
echo "➡️ Node version: $(node -v)"
echo "➡️ NPM version: $(npm -v)"

# --- Création dossier photomaton ---
echo "📂 Création du dossier $INSTALL_DIR"
mkdir -p "$INSTALL_DIR"
cd "$INSTALL_DIR"

# --- Décompression de l’archive (si présente) ---
if [ -f "/mnt/data/photomaton_full.zip" ]; then
  echo "📦 Extraction de photomaton_full.zip"
  unzip -o /mnt/data/photomaton_full.zip -d "$INSTALL_DIR"
fi

# --- Backend Node ---
echo "📦 Installation du backend Node"
cd "$INSTALL_DIR/node_backend"
npm install

# --- Backend Python ---
echo "📦 Installation du backend Python"
cd "$INSTALL_DIR/python_backend"
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
deactivate

# --- Frontend React ---
echo "📦 Installation du frontend React"
cd "$INSTALL_DIR/frontend"
npm install
npm run build

# --- Configuration CUPS ---
echo "🖨️ Configuration de CUPS"
sudo usermod -a -G lpadmin $USER
sudo systemctl enable cups
sudo systemctl start cups

# --- Services systemd ---
echo "⚙️ Installation du service systemd"
sudo cp "$INSTALL_DIR/scripts/photomaton.service" /etc/systemd/system/photomaton.service
sudo systemctl daemon-reload
sudo systemctl enable photomaton.service

# --- Fin ---
echo "✅ Installation terminée."
echo "➡️ Backend : http://localhost:4002"
echo "➡️ Frontend : http://localhost:3000"
echo "➡️ Galerie  : http://localhost:4002/"
