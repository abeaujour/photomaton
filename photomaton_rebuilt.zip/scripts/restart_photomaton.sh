#!/bin/bash
set -e
sudo systemctl restart photomaton.service || true
sudo systemctl restart photomaton-node.service || true
sudo systemctl restart photomaton-python.service || true
echo "✅ Services redémarrés."
