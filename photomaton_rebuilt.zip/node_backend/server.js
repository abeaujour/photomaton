import express from "express";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { exec } from "child_process";

let ws281x = null;
let onoff = null;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const config = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "config.json"), "utf8"));

const app = express();
app.use(express.json({ limit: "50mb" }));

app.use("/photos", express.static(config.baseDir));
app.use("/assets", express.static(path.join(__dirname, "..", "assets")));
if (config.eventLogo && fs.existsSync(path.join(__dirname, "..", "assets"))) {
  app.use("/logo", express.static(path.join(__dirname, "..", "assets")));
}

function ensureDayFolder() {
  const now = new Date();
  const day = now.toISOString().split("T")[0];
  const folder = path.join(config.baseDir, day);
  fs.mkdirSync(folder, { recursive: true });
  return { now, day, folder };
}

function safeTitle() {
  return (config.eventTitle || "Photomaton")
    .replace(/[^a-z0-9]+/gi, "_")
    .replace(/^_+|_+$/g, "")
    .substring(0, 30);
}

function timestampName(ext = "jpg", suffix = null) {
  const now = new Date();
  const ts = now.toISOString().replace(/:/g, "-").split(".")[0];
  const title = safeTitle();
  return suffix ? `${ts}_${title}_${suffix}.${ext}` : `${ts}_${title}.${ext}`;
}

app.get("/config", (req, res) => res.json(config));

let pixelData = null;
let idleInterval = null;
let flashGpio = null;

function hexColor(r, g, b) { return ((r & 0xff) << 16) | ((g & 0xff) << 8) | (b & 0xff); }

async function setupLights() {
  if (config.flashMode === "gpio") {
    if (!onoff) { onoff = await import("onoff"); }
    if (!flashGpio) {
      flashGpio = new onoff.Gpio(config.gpioPin || 18, "out");
      flashGpio.writeSync(0);
    }
  } else if (config.flashMode === "neopixel") {
    if (!ws281x) {
      const lib = await import("rpi-ws281x-native").catch(()=>null);
      if (!lib) { console.warn("rpi-ws281x-native non installé."); return; }
      ws281x = lib.default;
      const count = config.neopixelCount || 16;
      ws281x.init(count, { gpio: config.neopixelPin || 21, stripType: ws281x.stripType.WS2812 });
      pixelData = new Uint32Array(count);
      startIdleAnimation();
    }
  }
}

function clearPixels() { if (!pixelData || !ws281x) return; for (let i=0;i<pixelData.length;i++) pixelData[i]=0x0; ws281x.render(pixelData); }
function setColor(color) { if (!pixelData || !ws281x) return; for (let i=0;i<pixelData.length;i++) pixelData[i]=color; ws281x.render(pixelData); }
function hsvToRgb(h, s, v) { const f=(n,k=(n+h/60)%6)=>Math.round(255*(v - v*s*Math.max(Math.min(k,4-k,1),0))); return ((f(5)&255)<<16)|((f(3)&255)<<8)|(f(1)&255); }

function startIdleAnimation() {
  if (!pixelData || !ws281x) return;
  if (idleInterval) return;
  const mode = config.neopixelIdleAnimation || "chase";
  let offset = 0;
  idleInterval = setInterval(() => {
    if (mode === "chase") {
      for (let i = 0; i < pixelData.length; i++) {
        const on = ((i + offset) % pixelData.length) < 2;
        pixelData[i] = on ? ((255<<16)|(80<<8)|180) : 0x000010;
      }
      ws281x.render(pixelData);
    } else if (mode === "rainbow") {
      for (let i = 0; i < pixelData.length; i++) {
        const hue = (i * 360 / pixelData.length + offset) % 360;
        pixelData[i] = hsvToRgb(hue, 1, 0.3);
      }
      ws281x.render(pixelData);
    }
    offset = (offset + 1) % pixelData.length;
  }, 80);
}

function stopIdleAnimation() { if (idleInterval) { clearInterval(idleInterval); idleInterval=null;} clearPixels(); }

async function neopixelCountdown(seconds=3) {
  if (!pixelData || !ws281x) return;
  const colors = [ ((255<<16)|(0<<8)|0), ((255<<16)|(165<<8)|0), ((0<<16)|(255<<8)|0) ];
  for (let s=seconds; s>0; s--) { setColor(colors[Math.min(colors.length-1, seconds - s)] || (255<<16)); await new Promise(r=>setTimeout(r,1000)); }
  clearPixels();
}

async function neopixelFlash() { if (!pixelData || !ws281x) return; setColor((255<<16)|(255<<8)|255); await new Promise(r=>setTimeout(r, config.neopixelFlashDuration || 200)); clearPixels(); }

app.post("/dslr/capture", async (req, res) => {
  await setupLights();
  const { day, folder } = ensureDayFolder();
  const name = timestampName("jpg");
  const filepath = path.join(folder, name);

  const doCapture = () => {
    exec(`gphoto2 --capture-image-and-download --filename="${filepath}"`, (err, stdout, stderr) => {
      if (err) { console.error("DSLR capture error:", stderr || err); return res.status(500).send("Capture DSLR échouée"); }
      res.json({ path: filepath, url: `/photos/${day}/${name}` });
    });
  };

  if (config.flashMode === "gpio" && flashGpio) {
    flashGpio.writeSync(1);
    setTimeout(() => { doCapture(); setTimeout(() => flashGpio.writeSync(0), 200); }, 50);
  } else if (config.flashMode === "neopixel" && ws281x) {
    stopIdleAnimation(); await neopixelCountdown(config.countdownSeconds || 3); await neopixelFlash(); doCapture(); startIdleAnimation();
  } else { doCapture(); }
});

app.post("/assemble", async (req, res) => {
  const sharp = await import("sharp");
  const { photos } = req.body;
  if (!photos || photos.length < config.photosPerSession) return res.status(400).send("Données insuffisantes.");

  const { day, folder } = ensureDayFolder();
  const dpi = config.dpi || 300;
  const w = Math.round((10/2.54)*dpi), h = Math.round((15/2.54)*dpi);
  const cellW = Math.floor(w/2), cellH = Math.floor(h/2);

  async function readImage(p) {
    if (p.startsWith("/photos/")) return fs.readFileSync(path.join(config.baseDir, p.replace("/photos/","")));
    return fs.readFileSync(p);
  }

  const bufs = [];
  for (let i=0;i<config.photosPerSession;i++) bufs.push(await readImage(path.join(config.baseDir, photos[i].replace("/photos/",""))));

  let logoBuf=null; const logoPath = path.join(__dirname, "..", "assets", path.basename(config.eventLogo||"logo.png"));
  if (fs.existsSync(logoPath)) logoBuf = fs.readFileSync(logoPath);

  const composites = [];
  for (let i=0;i<3;i++) composites.push({ input: await (await import("sharp")).then(m=>m.default(bufs[i]).resize(cellW, cellH).toBuffer()), top: Math.floor(i/2)*cellH, left: (i%2)*cellW });
  if (logoBuf) composites.push({ input: await (await import("sharp")).then(m=>m.default(logoBuf).resize(cellW, cellH).toBuffer()), top: cellH, left: cellW });

  const plancheName = timestampName("jpg");
  const planchePath = path.join(folder, plancheName);
  await (await import("sharp")).then(m=>m.default({ create: { width: w, height: h, channels: 3, background: "#ffffff" } })
    .composite(composites).jpeg({ quality: 95 }).toFile(planchePath));

  if (config.printToPDF) {
    const pdfDir = config.pdfOutputDir || "/home/denre/photomaton-pdf";
    fs.mkdirSync(pdfDir, { recursive: true });
    const pdfName = plancheName.replace(/\.jpg$/i, ".pdf");
    const pdfPath = path.join(pdfDir, pdfName);
    exec(`cupsfilter "${planchePath}" > "${pdfPath}"`, (err)=>{ if (err) console.warn("cupsfilter failed:", err && err.message); });
  }

  if (config.printEnabled && (config.printMode === "auto" || config.printMode === "both")) {
    const copies = config.printCopies || 1;
    exec(`lp -d ${config.printerName} -n ${copies} "${planchePath}"`, (err, stdout, stderr) => { if (err) console.error("Erreur impression auto:", stderr); });
  }

  res.json({ planchePath, url: `/photos/${day}/${path.basename(planchePath)}` });
});

app.post("/print", (req, res) => {
  const { file } = req.body;
  if (!config.printEnabled) return res.status(403).send("Impression désactivée");
  if (!file || !file.startsWith(config.baseDir)) return res.status(400).send("Fichier invalide");
  const copies = config.printCopies || 1;
  exec(`lp -d ${config.printerName} -n ${copies} "${file}"`, (err) => { if (err) return res.status(500).send("Erreur impression"); res.send("OK"); });
});

app.get("/", (req, res) => {
  if (!fs.existsSync(config.baseDir)) fs.mkdirSync(config.baseDir, { recursive: true });
  const days = fs.readdirSync(config.baseDir).filter(d => fs.statSync(path.join(config.baseDir, d)).isDirectory()).sort().reverse();
  const bg = `background:linear-gradient(45deg, ${(config.themes[config.themePreset]||config.themes.retro).gradientColors.join(",")}); color:white;`;
  let html = `
  <html><head><meta charset="utf-8"><title>${config.eventTitle}</title>
  <style>body{font-family:sans-serif;margin:0;padding:1em;${bg}}h1{text-align:center;margin:0 0 10px 0}h2{margin-top:1em;border-bottom:1px solid rgba(255,255,255,0.4)}.grid{display:flex;flex-wrap:wrap;gap:12px}img{height:160px;border-radius:12px;box-shadow:0 4px 12px rgba(0,0,0,0.3)}.toolbar{text-align:center;margin:12px 0}.btn{padding:8px 14px;border-radius:10px;background:#ffffff;color:#111;font-weight:bold}</style></head><body>
  <h1>${config.eventTitle}</h1><div class="toolbar"><a class="btn" href="/slideshow" target="_blank">Ouvrir le diaporama</a></div>`;
  for (const day of days) { html += `<h2>${day}</h2><div class="grid">`; const files = fs.readdirSync(path.join(config.baseDir, day)).filter(f => f.toLowerCase().endsWith(".jpg")); for (const f of files) html+=`<a href="/photos/${day}/${f}" target="_blank"><img src="/photos/${day}/${f}"/></a>`; html += `</div>`; }
  html += `<script>setInterval(()=>location.reload(), ${config.galleryRefreshMs||30000});</script></body></html>`;
  res.send(html);
});

app.get("/photos-list", (req, res) => {
  if (!fs.existsSync(config.baseDir)) return res.json([]);
  const days = fs.readdirSync(config.baseDir).filter(d => fs.statSync(path.join(config.baseDir, d)).isDirectory()).sort().reverse();
  const imgs = []; for (const day of days) { const files = fs.readdirSync(path.join(config.baseDir, day)).filter(f => f.toLowerCase().endsWith(".jpg")); for (const f of files) imgs.push(`/photos/${day}/${f}`); }
  res.json(imgs);
});

app.get("/slideshow", (req, res) => {
  const html = `<html><head><meta charset="utf-8"><title>Slideshow</title><style>body{margin:0;background:#000;display:flex;align-items:center;justify-content:center;height:100vh}img{max-width:100%;max-height:100%;border-radius:8px}</style></head><body><img id="slide"/><script>const interval=${config.slideshowInterval||5000}; const refresh=${config.galleryRefreshMs||30000}; let imgs=[], idx=0; function tick(){ if(imgs.length){ document.getElementById('slide').src = imgs[idx]; idx=(idx+1)%imgs.length; } } async function refreshList(){ try{ const r=await fetch('/photos-list'); imgs=await r.json(); idx=0; }catch(e){} } setInterval(tick, interval); setInterval(refreshList, refresh); refreshList(); tick();</script></body></html>`;
  res.send(html);
});

app.listen(config.backendPort, () => { console.log(`Backend Node en écoute sur http://localhost:${config.backendPort}`); setupLights(); });
